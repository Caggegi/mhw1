# Database e Web Programming - mhw1
## Introduzione
Repository del primo minihomework di Database e Web programming 2020/2021 modulo Web programming
## Concept
Vorrei realizzare una piattaforma simile agli ormai popolarissimi YouTube e Twitch che permetta agli utenti di usufruire dei contenuti creati dai loro artisti preferiti. 
Gli utenti premium possono abbonarsi o meno a un Creator così da supportarlo.


### Credits:
Rosario Caggegi o46002042     
[![GitHub - mhw1](https://github.com/Caggegi/mhw1/blob/master/img/Light/github.svg)](https://github.com/Caggegi/mhw1)
[![Instagram](https://github.com/Caggegi/mhw1/blob/master/img/Light/instagram.svg)](https://www.instagram.com/rosario.caggegi/)
[![Facebook](https://github.com/Caggegi/mhw1/blob/master/img/Light/facebook.svg)](https://www.facebook.com/rosario.caggegi.142/)

